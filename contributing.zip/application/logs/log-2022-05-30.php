<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-30 08:21:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-05-30 08:26:07 --> 404 Page Not Found: Assets/css
